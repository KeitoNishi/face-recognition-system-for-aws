import { Suspense } from "react"
import { getVenues } from "@/lib/db"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import Link from "next/link"
import { UserHeader } from "@/components/user-header"
import { FaceRegistrationButton } from "@/components/face-registration-button"

export const dynamic = "force-dynamic"

async function VenuesList() {
  const venues = await getVenues()

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
      {venues.map((venue) => (
        <Card key={venue.id} className="hover:shadow-md transition-shadow">
          <CardHeader>
            <CardTitle>{venue.name}</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-gray-600 mb-4">
              作成日: {new Date(venue.created_at).toLocaleDateString("ja-JP")}
            </p>
            <Link
              href={`/venues/${venue.id}`}
              className="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md text-white bg-blue-600 hover:bg-blue-700"
            >
              写真を見る
            </Link>
          </CardContent>
        </Card>
      ))}
    </div>
  )
}

export default function VenuesPage() {
  return (
    <div className="container mx-auto py-6">
      <UserHeader />
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-3xl font-bold">会場一覧</h1>
        <FaceRegistrationButton />
      </div>
      <Suspense fallback={<div>会場一覧を読み込み中...</div>}>
        <VenuesList />
      </Suspense>
    </div>
  )
}
