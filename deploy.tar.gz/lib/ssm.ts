import { SSMClient, GetParameterCommand } from "@aws-sdk/client-ssm";

const ssm = new SSMClient({ region: "ap-northeast-1" });

async function getParameter(name: string) {
  const command = new GetParameterCommand({
    Name: name,
    WithDecryption: true,
  });
  const response = await ssm.send(command);
  if (!response.Parameter?.Value) throw new Error(`Parameter ${name} not found`);
  return response.Parameter.Value;
}

export async function getConfig() {
  return {
    databaseUrl: await getParameter("/face-recognition-system/test/databaseUrl"),
    awsAccessKey: await getParameter("/face-recognition-system/test/awsAccessKey"),
    awsSecretKey: await getParameter("/face-recognition-system/test/awsSecretKey"),
    s3Bucket: await getParameter("/face-recognition-system/test/s3Bucket"),
    rekognitionCollectionId: await getParameter("/face-recognition-system/test/rekognitionCollectionId"),
    adminUsername: await getParameter("/face-recognition-system/test/adminUsername"),
    adminPassword: await getParameter("/face-recognition-system/test/adminPassword"),
    userCommonPassword: await getParameter("/face-recognition-system/test/userCommonPassword"),
  };
} 