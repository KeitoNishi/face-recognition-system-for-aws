#!/bin/bash

# 完全自動化デプロイスクリプト（ローカル完全ビルド + PM2起動）
# 使用方法: ./deploy_with_pm2.sh

set -e  # エラーが発生したら即座に終了

# 設定
EC2_KEY_PATH="/Users/keito/workspace/key-aws/ec2-key-pair.pem"
EC2_HOST="ec2-user@3.115.6.35"
DEPLOY_PATH="/home/ec2-user/app/face-recognition"
PROJECT_ARCHIVE="deploy-complete.tar.gz"
APP_NAME="face-recognition-app"

echo "🚀 完全自動化デプロイを開始します（ローカル完全ビルド + PM2）..."

# 1. ローカルで依存関係インストール
echo "📦 ローカルで依存関係をインストール中..."
npm install --legacy-peer-deps

echo "✅ 依存関係インストール完了"

# 2. ローカルでビルド実行
echo "🔨 ローカルでビルド実行中..."
npm run build

echo "✅ ビルド完了"

# 3. 完全デプロイパッケージを圧縮（node_modules含む）
echo "📦 完全デプロイパッケージを圧縮中..."
tar -czf $PROJECT_ARCHIVE \
    .next \
    public \
    package.json \
    next.config.mjs \
    node_modules

echo "✅ デプロイパッケージ圧縮完了"

# 4. EC2サーバーの既存ファイル削除と新しいディレクトリ作成
echo "🗑️  EC2サーバーの既存ファイルを削除中..."
ssh -i $EC2_KEY_PATH $EC2_HOST \
    "rm -rf .next app components hooks lib middleware.ts next.config.mjs package.json pnpm-lock.yaml public scripts styles types deploy-clean.tar.gz && mkdir -p app/face-recognition"

echo "✅ EC2サーバーのクリーンアップ完了"

# 5. 完全パッケージをEC2に転送
echo "📤 完全パッケージをEC2に転送中..."
scp -i $EC2_KEY_PATH $PROJECT_ARCHIVE $EC2_HOST:$DEPLOY_PATH/

echo "✅ ファイル転送完了"

# 6. EC2サーバー上でパッケージを展開
echo "📂 EC2サーバー上でパッケージを展開中..."
ssh -i $EC2_KEY_PATH $EC2_HOST \
    "cd $DEPLOY_PATH && tar -xzf $PROJECT_ARCHIVE && rm $PROJECT_ARCHIVE"

echo "✅ パッケージ展開完了"

# 7. EC2でPM2インストール（未インストールの場合）
echo "⚙️  PM2をインストール・設定中..."
ssh -i $EC2_KEY_PATH $EC2_HOST \
    "which pm2 || npm install -g pm2"

echo "✅ PM2準備完了"

# 8. 環境変数設定
echo "🌍 環境変数を設定中..."
ssh -i $EC2_KEY_PATH $EC2_HOST \
    "echo 'export NODE_ENV=production' >> ~/.bashrc && source ~/.bashrc"

echo "✅ 環境変数設定完了"

# 9. PM2でアプリケーション停止・削除（既存プロセスがある場合）
echo "🛑 既存のPM2プロセスを停止中..."
ssh -i $EC2_KEY_PATH $EC2_HOST \
    "cd $DEPLOY_PATH && pm2 stop $APP_NAME || true && pm2 delete $APP_NAME || true"

echo "✅ 既存プロセス停止完了"

# 10. PM2でアプリケーション起動
echo "🚀 PM2でアプリケーションを起動中..."
ssh -i $EC2_KEY_PATH $EC2_HOST \
    "cd $DEPLOY_PATH && NODE_ENV=production pm2 start npm --name '$APP_NAME' -- start"

echo "✅ アプリケーション起動完了"

# 11. PM2プロセス保存（再起動時の自動起動用）
echo "💾 PM2設定を保存中..."
ssh -i $EC2_KEY_PATH $EC2_HOST \
    "pm2 save && pm2 startup | grep 'sudo' | sh || true"

echo "✅ PM2設定保存完了"

# 12. ローカルの一時ファイルを削除
echo "🧽 ローカルの一時ファイルを削除中..."
rm -f $PROJECT_ARCHIVE

echo "✅ ローカルクリーンアップ完了"

# 13. デプロイ完了の確認
echo "🔍 デプロイ結果を確認中..."
ssh -i $EC2_KEY_PATH $EC2_HOST \
    "cd $DEPLOY_PATH && echo '📍 デプロイ先: $DEPLOY_PATH' && echo '🔄 PM2プロセス状態:' && pm2 list && echo '📊 アプリケーションログ:' && pm2 logs $APP_NAME --lines 10"

echo ""
echo "🎉 完全自動化デプロイが完了しました！"
echo "📍 デプロイ先: $DEPLOY_PATH"
echo "🌐 アプリケーションは次のURLでアクセス可能："
echo "   http://3.115.6.35:3000"
echo ""
echo "🔧 PM2管理コマンド:"
echo "   📊 状態確認: ssh -i $EC2_KEY_PATH $EC2_HOST 'pm2 list'"
echo "   📋 ログ確認: ssh -i $EC2_KEY_PATH $EC2_HOST 'pm2 logs $APP_NAME'"
echo "   🔄 再起動: ssh -i $EC2_KEY_PATH $EC2_HOST 'pm2 restart $APP_NAME'"
echo "   🛑 停止: ssh -i $EC2_KEY_PATH $EC2_HOST 'pm2 stop $APP_NAME'"
echo "   🗑️  削除: ssh -i $EC2_KEY_PATH $EC2_HOST 'pm2 delete $APP_NAME'" 