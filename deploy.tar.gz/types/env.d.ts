// Parameter Store方式に移行したため、下記は利用しません
// declare namespace NodeJS {
//   interface ProcessEnv {
//     DATABASE_URL: string
//     AWS_REGION: string
//     AWS_ACCESS_KEY_ID: string
//     AWS_SECRET_ACCESS_KEY: string
//     S3_BUCKET_NAME: string
//     REKOGNITION_COLLECTION_ID: string
//     ADMIN_USERNAME: string
//     ADMIN_PASSWORD: string
//     USER_PASSWORD: string
//   }
// }
